// Define the `phonecatApp` module
var myApp = angular.module('myApp', []);

// Define the `PhoneListController` controller on the `phonecatApp` module
myApp.controller('myCtrl',function($scope) {
     $scope.MakeMapVisible=!$scope.MakeMapVisible
});
